import UIKit
class Fonksiyonlar {
    //döndürme olmayan void fonksiyonlar
    
    func selamla1(){
        let sonuc = "Merhaba Ahmet"
        print (sonuc)
    }
    
    //geri dönüş değeri olan (return)
    
    func selamla2() -> String {
        let sonuc = "Merhaba Ahmet"
        return sonuc
    }
    func selamla3(isim:String){
        let sonuc = "Merhaba \(isim)"
        print(sonuc)
    }
    
    func toplam(sayi1:Int, sayi2:Int) -> Int {
        let toplam = sayi1 + sayi2
        return toplam
    }
    
    
    
    
    //overloading yapısı: aynı kod satırını birden fazla kere aynı şekilde kullanmak istersek bunun üzerinde hafif düzenleme yapmak gerekir. Bunun için birden fazla yol vardır. örnekle bakalım.
    
    func carpma (sayi1:Int, sayi2:Int){
        print ("Çarpma : \(sayi1 * sayi2)")
    }
    //func carpma (sayi1:Int, sayi2:Int){
    //   print ("Çarpma :\(sayi1 * sayi2)")
    //} bu şekilde bire bir aynı yazarsak hata verir. Biz bunun yerine tür dğeiştirme yapabiliriz. yani int olan yerleri double yapalım.
    
    func carpma (sayi1:Double, sayi2:Double){
        print ("Çarpma : \(sayi1 * sayi2)")
    }
    //tabi ki sadece tür değiştirmek de değil, bir yandan farklı bir parametre ekleyerek de bu sorunu çözebiliriz. Bunun için ek bir string değeri eklebilir. Yani;
    func carpma (sayi1:Int, sayi2:Int, isim:String){
        print("Çarpma : \(sayi1 * sayi2) - İşlemi Yapan : \(isim)")
    }
}
let f = Fonksiyonlar()

f.selamla1()
let gelenSonuc = f.selamla2()
print("Gelen Sonuç : \(gelenSonuc)")

f.selamla3(isim: "Zeynep")

let gelenToplam = f.toplam(sayi1: 10, sayi2: 20)
print("Gelen Toplam :\(gelenToplam)")

f.carpma(sayi1: 10, sayi2: 30, isim: "Zeynep")
